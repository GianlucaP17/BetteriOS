import Foundation
///Oggi parliamo di Functional Programming,
///ha l'obbiettivo di scrivere codice meno falloso e più facile da leggere,
///appena impariamo a programmare solitamente si usa Imperative Programming, il quale fa dei passaggi lunghi e meccanici, ma solo visivamente
///perchè se voglio, funziona comunque ma è meno leggibile
///l'imperativo cambia lo stato della app, il functional, che sio spezzetta in piccole funzioni non modifica ma è uno strumento


///obbiettivo: print array con nome specifico
print(filter(array: personeArray, name: "giangi"))

///imperative way - questa funzione imperative parla ad ogni passaggio
func filter(array: [Person], name: String) -> [Person] {
    //creiamo un arrya vuoto
    var result = [Person]()
    //for loop per ogni item
    for item in array {
        //facciamo un check
        if item.name == name {
            //append se worka
            result.append(item)
        }
    }
    return result
}

///modello di base
struct Person {
    let name : String
    ///posso aggiungere altri parametri da utilizzare.... tipo città, età ecc...
}
/// dati mock da utilizzare
let personeArray: [Person] = [
    Person(name:"giangi"),
    Person(name:"davi"),
    Person(name:"gabry"),
    Person(name:"giangi"),
    Person(name:"silvio"),
    Person(name:"lalla"),
    Person(name:"lolla"),
    Person(name:"giangi"),
    Person(name:"nonna"),
    Person(name:"luca")
]

///Come renderla Functional e dichiarativa
///sto dicendo "dimmi i nomi" e non "per ogni oggetto fai questa... poi.... e ridammi...
func filter1(array: [Person], name: String) -> [Person] {
    array.filter({ $0.name == name })
    //non serve il return essendo single line func
}



///Esempio reale su un oggetto di parco giochi

let sortedNames1 = sortedNamesImp(of: parkRides)
///Imperative way
func sortedNamesImp(of rides: [Ride]) -> [String] {
    var sortedNames: [String] = []
    for ride in rides {
        sortedNames.append(ride.name)
    }
    sortedNames = sortedNames.sorted { primo, secondo in
        return primo < secondo
    }
    
    return sortedNames
}

///arry di oggetti
let parkRides = [
    Ride(name: "Raging Rapids", categories: [.family, .thrill, .water], waitTime: 45.0),
    Ride(name: "Crazy Funhouse", categories: [.family], waitTime: 10.0),
    Ride(name: "Spinning Tea Cups", categories: [.kids], waitTime: 15.0),
    Ride(name: "Spooky Hollow", categories: [.scary], waitTime: 30.0),
    Ride(name: "Thunder Coaster", categories: [.family, .thrill], waitTime: 60.0),
    Ride(name: "Grand Carousel", categories: [.family, .kids], waitTime: 15.0),
    Ride(name: "Bumper Boats", categories: [.family, .water], waitTime: 25.0),
    Ride(name: "Mountain Railroad", categories: [.family, .relaxing], waitTime: 0.0)
]

///categoria
enum RideCategory: String {
    case family,kids,thrill,scary,relaxing,water
}
///oggetto intero
struct Ride: CustomStringConvertible {
    let name: String
    let categories: Set<RideCategory>
    let waitTime: Double // in coda
    
    var description: String {
        return "Ride –\"\(name)\", wait: \(waitTime) mins, " +
        "categories: \(categories)\n"
    }
}


///In fp (functional programming), Collections have methods, che sono Higher Order Function (HOF) = è una funzione che prende come parametri funzioni e fa un return func. cosi dando il risultato alla var

///Vediamo alcuni metodi
///

///In fp (functional programming) le funzioni possono essere assegnate ad una variabile, a sua volta una funzione può essere attaccata ad una altra funzione! In particolare andiamo a vedere filter, map, reduce

///Filter - tiene conto solo di item con una certa condizione
///
///Come funziona filter?
let apples = ["🍎", "🍏", "🍎", "🍏", "🍏"]
let greenapples = apples.filter { $0 == "🍏"}
print(greenapples)
///prende come parametro una funzione, la quale accetta un solo item dal array alla volta, quindi fa un for loop, a cui si  fa un check con un altro elemento (in base a quello che vogliamo fargli fare)
///Filter restituisce sempre un nuovo array, se voglio, con gli oggetti che restituiscono "true" alla logica nella funzione

///ora... come possiamo riassumere le closures
///essendo le funzioni in swift closures (prende un parametro e ne ritorna qualcosa) possiamo avere lo stesso risultato in questa maniera
///closures:
///         { (parameters) -> return type in
///             statements
///         }  -> ridà qualcosa

///esempio di closures
var reversedNames = ["Bumper Boats","Crazy Funhouse"]
///come pulire closures
reversedNames = reversedNames.sorted(by: { (s1: String, s2: String) -> Bool in
    let res = s1 > s2
    return res
})
///cosi è imperativa in parte... trasformiamola!
reversedNames = reversedNames.sorted(by: { $0 > $1 } )
///o anche meglio, refactor
reversedNames = reversedNames.sorted(by: > )

///per il nostro esempio, cerchiamo chi dura meno di 15.0, da qui...
func waitTimeIsShort(_ ride: Ride) -> Bool {
    return ride.waitTime < 15.0
}
///passo la funzione, che automaticamente passa $0 come param alla func
let shortWaitTimeRides = parkRides.filter(waitTimeIsShort)
print("rides with a short wait time:\n\(shortWaitTimeRides)")
///come metterla meglio?
let shortWaitTimeRides2 = parkRides.filter { $0.waitTime < 15.0 }
print(shortWaitTimeRides2)

///ora abbiamo capito come fare il sort... capiamo come prendere solo i nomi...

///Map & Compact Map - crea nuovo array da item in oggetto
///
///prendere una funzione come parametro e applica lo statement al contenuto di quell'oggetto, non ritornando per forza lo stesso element type
///let apples = ["🍎", "🍏", "🍎", "🍏", "🍏"]
let oranges = apples.map { _ in "🍊" }
print(oranges)
///ora abbiamo un nuovo array dove tutte gli items di apple sono convertiti nel nuovo item

///con map posso creare un nuovo array type in base ad un contenuto all'interno del item
var rideNames = parkRides.map { $0.name }
print(rideNames) ///ora ho solo i nomi!

///li prende anche nulli... quindi se ho un parametro
///"name = nil" e non voglio catturarlo...
rideNames = parkRides.compactMap { $0.name }
print(rideNames)

/// tutti gli elementi che possono avere Map > sono detti Functors, invece chi può avere flatMap sono Monads

///Altrimenti se ho un array all'interno di items di un array e voglio prendere tutti gli array interni degli oggetti....
///FlatMap!
print("all categories", (parkRides.map({$0.categories})))
/// cosi mi stampa [["",""],[""],["","",""]], voglio tutto unito!
print("all categories", (parkRides.flatMap({$0.categories})))
/// cosi mi stampa ["","","","",], voglio tutto unito!

///ora vediamo come trasformare sortedNamesImp in declarative functional programming....
func sortedNamesFP(_ rides: [Ride]) -> [String] {
    let rideNames = rides.map { $0.name }
    return rideNames.sorted(by: <)
}
let sortedNames2 = sortedNamesFP(parkRides)
///anche meglio
func sortedNamesFP1(_ rides: [Ride]) -> [String] {
    return rides.map { $0.name }.sorted(by: <)
}
///oppure
let sortedRideNames1 = parkRides.compactMap{$0.name}.sorted(by: <)

///abbiamo trovato come prendere il risultato con una linea


///Reduce- calcolare il totale, sommare a qualcosa
///
///reduce prende due parametri
///il primo è un T (valore generico) dichiarato nuovo
///il secondo è una funzione che combina (+) il valore di T con quello di un elemento del item (aggiunge)
let totalWaitTime = parkRides.reduce(0.0) { (total, ride) in
    total + ride.waitTime
}
print("total wait time for all rides = \(totalWaitTime) Double")
///Iteration    initial    ride.waitTime    resulting total
///    1          0            45            0 + 45 = 45
///    2         45            10            45 + 10 = 55
///    …
///    8        200             0            200 + 0 = 200


///Tecniche avanzate

///Partial functions
///
///una funzione può avere un'altra funzione al suo interno
///se  voglio dare parametro base ma specificare ogni volta il secondo...
func add(_ x: Int) -> ((Int) -> Int) {
    return { y in
        return x + y
    }
}
/// qui diciamo che voglio utilizzare come base il 3, quindi la funzione farà sempre la somma con 3 + parametro che inserirò nella func che ricevo "(Int) -> Int)"
let add3 = add(3)
///ora voglio fare la somma con il 4
let sum1 = add3(4)
///da qui viene il nome Partial functions, perchè non è una funzione completa ma spezzata e completata in secondo luogo
print(sum1)
///in pratica, io qui preimposto la somma con cosa deve essere fatta, successivamente mando l'oggetto da sommare!

///come parametro dobbiamo dare la categoria di ride... e ho indietro una funzione parziale! con la base un filtro da applicare
func filter(for category: RideCategory) -> ([Ride]) -> [Ride] {
    return { rides in
        rides.filter { $0.categories.contains(category) }
    }
}
///io qui preimposto il filtro come deve essere fatto, successivamente mando l'array da filtrare!
let kidRideFilter = filter(for: .kids)
///creo una funzione filter di base, ne creo una seconda con un parametro già impostato e la uso come altra base....
///let kidRideFilter:  ([Ride]) -> [Ride]    > ho indietro una funzione parziale che vuole un parametro array in questo caso da filtrare secondo "filter for category"
print("some good rides for kids are:\n\(kidRideFilter(parkRides))")
/// qui non specifico come deve essere filtrato ma solo cosa, come già messo prima

///Pure functions
///
///una funzione è pura se rispetta:
///il return value è determinato dal suo input value, senza modificare dati esterni
///in pratica gli do un dato, e ne ritorna uno uguale, ma non ha legami con esterno, è astratto, buona base per capire concetto di "Astratto" in swift, cosi da essere riutilizzabile e modulabile
func ridesWithWaitTimeUnder(_ waitTime: Double,
                            from rides: [Ride]) -> [Ride] {
    return rides.filter { $0.waitTime < waitTime }
}
let shortWaitRides = ridesWithWaitTimeUnder(15, from: parkRides)


///Recursion
///

///le funzioni che richiamano se stesse all'interno, tipo ho uno specchio che guarda un altro specchio, verrà chiamato infinite volte
///bad side effect: se loop troppi dati troppo peso, questa non ha spam
func countDownToZero(num: Int) {
    print(num)
    if num > 0 {
        countDownToZero(num: num - 1)
    }
}
print("Countdown:\(countDownToZero(num:6))")


///Imperative vs. Declarative Code Style

///vediamo il vero utilizzo con questo esempio:
///A family with young kids wants to go on as many rides as possible between frequent bathroom breaks. They need to find which kid-friendly rides have the shortest lines. Help them out by finding all family rides with wait times less than 20 Double and sort them by the shortest to longest wait time.
///
///provate a risolvere il problema con uno style imperativo.
///obiettivo? lista rides che possiamo fare che hanno meno di 20 m di attesa
var ridesOfInterest: [Ride] = []
for ride in parkRides {
    if ride.waitTime < 20 {
        for category in ride.categories {
            if category == .family {
                ridesOfInterest.append(ride)
                break
            }
        }
    }
}
print(ridesOfInterest.sorted(by: {$0.waitTime < $1.waitTime}))

///Solving the Problem with a Functional Approach, declarative, meaning it’s self-explanatory and reads like the problem statement it solves
let sortedRidesOfInterest2 = parkRides
    .filter { $0.categories.contains(.family) && $0.waitTime < 20 }
    .sorted(by: {$0.waitTime < $1.waitTime})



///Altri esempi...

///Imperative Programming
var total = 0
for i in 1...10 {
    total += i
}
print("Imperative: total: ", total); /// prints 55

///Functional Programming
func sum(start: Int, end: Int, total: Int) -> Int {
    if (start > end) {
        return total;
    }
    return sum(start: start + 1, end: end, total: total + start)
}
print("Functional: total: ", sum(start: 1, end: 10, total: 0)); /// prints 55



struct Contact {
    var firstName: String
    var lastName: String
    var email: String
    var age: Int
    var duration: Int
}

let contacts = [
    Contact(firstName: "first", lastName: "1", email: "some@one1.com", age: 20, duration: 12),
    Contact(firstName: "Second", lastName: "2", email: "some@one2.com", age: 22, duration: 16),
    Contact(firstName: "Third", lastName: "3", email: "some@one3.com", age: 30, duration: 22)
]

///Get just the name of the contacts into a separate array

///Imperative Programming
var contactNamesImp = [String]()
for contact in contacts { /// for each
    contactNamesImp.append(contact.firstName)
}
print(contactNamesImp)

///Functional Programming
let contactNames = contacts.map({
    return $0.firstName + " " + $0.lastName
})
print(contactNames)


///prendiamo chi sopra certa età

///Imperative Programming
func filterContacts(aboveAge age: Int) -> [Contact] {
    var filteredContacts = [Contact]()
    for contact in contacts {
        if contact.age > age {
            filteredContacts.append(contact)
        }
    }
    return filteredContacts
}

///Functional Programming
let contactsAbove20 = contacts.filter({ $0.age > 20 })
print(contactsAbove20)


let contactsDurationArr = contacts.map({ $0.duration })
///We use the map function to derive an array that contains only the duration property of all the objects
var sum = 0
for duration in contactsDurationArr {
    sum = sum + duration
}
print(sum)

///Functional Programming, parte da primo param e fa tra i due quel operation
let totalDurationSpentByContacts = contactsDurationArr.reduce(0,+)
print(totalDurationSpentByContacts)
