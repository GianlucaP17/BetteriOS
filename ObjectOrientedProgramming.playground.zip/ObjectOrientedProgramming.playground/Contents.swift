import Foundation

/// Object oriented Programming in Swift - OOP, concetto base di swift
/// serve per creare dei modelli di dati più strutturati e riutilizzabili, evitare di avere una classe per ogni oggetto leggermente diverso, rispettando la regola DRY, "Don't repeat yourself"
/// concetti principali di Programmazione ad oggetti:
///
/// Classi
/// Oggetti
/// Proprietà
/// Metodi
/// Access Control
/// Encapsulation
/// Abstraction
/// Inheritance
/// Method Overloading
/// Method Overriding
/// Polymorphism

///una Classe cos'è?
///Le classi possono essere viste come gruppi di cose o esseri viventi a cui appartengono, le quali hanno proprietà simili
///esempio di "Strumenti musicali" dove abbiamo caratteristiche simili, ma non uguali

class StrumentoMusicale {
    ///esempio di classe base ma non significa nulla "Strumento musicale"... non è un oggetto ma una definizione, quindi che parametri ha questa definizione in generale? fa un suono ecc
}
///deve avere delle proprietà...

///cosa sono le Proprietà?
///tornando al esempio di prima con la classe "Strumenti musicale", hanno delle caratteristiche e funzioni che sono alla base degli strumenti, tutti hanno un brand, una funzione ecc.
///quindi le proprietà degli strumenti musicale, di base sono..

class Instrument {
///dichiariamo le proprietà alla base degli strumentu musicali
    var brand: String!
    var color: String!
    var materialType: String!
    
///inizializziamo esse, quando creiamo per la prima volta un oggetto di un classe, andiamo a specificare le sue proproetà
    init(brand: String, color: String, materialType: String) {
        self.brand = brand
        self.color = color
        self.materialType = materialType
    }
}

///un Oggetto cos'è?
///Un oggetto è qualsiasi cosa che appartiene a una classe
let chitarra = Instrument(brand: "apple", color: "Black", materialType: "wood")
///abbiamo creato un oggetto instanziando una classe

///questo strumento ha una definizione ma non fa nulla. dobbiamo fargli fare qualcosa...

///cosa sono i Metodi?
///all'interno delle classi, abbiamo le funzioni, che sono chiamate "metodi di una classe"
///esempio pratico, uno strumento musicale, dato il nome, fa una melodia
func suona() {
    print("Suono...")
}
///oppure:
func suonaMusica(titolo:String) {
    print("Sto suonando: \(titolo)")
}

///quindi la nostra classe diventa cosi:

class Instrument1 {
    var brand: String!
    var color: String!
    var materialType: String!
    
    init(brand: String, color: String, materialType: String) {
        self.brand = brand
        self.color = color
        self.materialType = materialType
    }
    
    func suona() {
        print("Suono...")
    }
}

let instrument = Instrument1(brand: "apple", color: "Black", materialType: "wood")
print(insturment.suona()) /// ("Suono...")

///non viglio ora che qualcuno possa andare a modificare la classe di base per avere una certa sicurezza.
///Voglio restringere l'accesso a questa classe, quindi Swift ha vari metodi per modificare il suo tipo di accesso...
///
///Open access and public access —  Entità, oggetti, che posso essere visti esternamente anche da altri moduli oltre alla mia "app"
open class Instrument2 {}
///Internal access —  Entità, oggetti, che posso essere visti solo dal mio modulo ma non da altri
internal class Instrument3 {}
///File-private access —Entità, oggetti, che posso essere visti SOLO all'interno di questo file
fileprivate class Instrument4 {}
///Private access — Entità, oggetti, che posso essere visti solo all'interno di questa classe
class Instrument5 {
    private class Instrument6 {
        func run() {}
    }
    
    //va
    func testInterno() {
        print(Instrument6().run())
    }
}
print(Instrument5().Instrument6().run())
///Non va perchè non ho chiamato all'interno della classe


///Altro metodo per "riservatezza"
///cosa è Encapsulation?
///serve per nascondere delle variabili all'interno della classe, non poterle modificare esternamente
///esempio che va oltre Instrument

///vogliamo calcolare il totale, ma non accedere alla variabile stessa (totale)
///fa di base dei calcol con dei parametri fornitii, come tutte le formule matematiche, che poi rilasciano un risultato
class Maths {
    
    ///due parametri di ingresso, i quali ci sono di base in ogni operazione matematica ma non definiamo l'operazione...
    let a: Int!
    let b: Int!
    //definiamo privata
    private var result: Int?
    
    ///carichiamo le variabili... inizializziamo
    init(a: Int,b: Int) {
        self.a = a
        self.b = b
    }
    
    ///creiamo un metodo base matematico...
    func add() {
        result = a + b
    }
    
    ///creiamo un metodo per mostrare il risultato
    func displayResult() {
        print("Result - \(result)")
    }
}
let calculation = Maths(a: 2, b: 3)
calculation.add()
calculation.displayResult()
///non abbiamo accesso alla variabile "result" > ma possiamo chiedere ad un metodo di dircelo, funziona per evitare di andare ad impattare dati sensibili da modifiche!
///nel motodo sopra sopra abbiamo "testInterno" che aiuta a esporre la funzione

///Inheritance, che cosa significa?
///ereditarietà delle classi, quindi, come una nuove classi posso ereditare dei metodi o parametri da una classe di base?
///torniamo sul nostro strumento....

class Instrument7 {
    var brand: String!
    var color: String!
    var materialType: String!
    
    init(brand: String, color: String, materialType: String) {
        self.brand = brand
        self.color = color
        self.materialType = materialType
    }
    
    func suona() {
        print("Suono...")
    }
}

///creiamo una nuova classe, ma al posto di nascere dal vuoto, nasce ed eredità qualcosa da una classe di base, in questo caso la chitarra è uno strumento musicale, quindi ha un brand ecc...
class Guitar: Instrument1 {
}

let guitar = Guitar(brand: "apple", color: "Black", materialType: "wood")
print(insturment.suona()) /// ("Suono...")

///fino a qui, abbiamo semplicemente cambiato nome a una classe

///Method Overloading
///che cosa è? ora vogliamo che quando suoni, indichiamo anche dopo quanti secondi aspettare, quindi, andiamo ad aggiungere la stessa funzione di prima, ma con un paramentro, accedendo a entrambi
class Guitar1: Instrument1 {
    func suona(secondi: Int) {
        print("tra \(secondi) secondi Suono...")
    }
}
let guitar1 = Guitar1(brand: "apple", color: "Black", materialType: "wood")
print(insturment.suona()) /// ("Suono...")
print(insturment.suona(secondi:12)) /// ("tra 12 secondi Suono...")

///vogliamo che nei parametri della classe vengano indicati anche quante corde ha la chitarra...

///Method Overriding
///qui dobbiamo andare a sovrastare una cosa della classe base, tenendo buona, l'ultima cosa override, ma con super, tengo buono e aggiungo il contenuto che voglio
class Guitar2: Instrument1 {
    var corde: Int!
    
    override init(brand: String, color: String, materialType: String, corde: Int!) {
        super.init()
        self.corde = corde
    }
    
    func quanteCorde() {
        print("la chitarra ha \(corde) di corde")
    }
}
let guitar2 = Guitar2(brand: "apple", color: "Black", materialType: "wood", corde: 10)
print(guitar2.quanteCorde()) ///"la chitarra ha 10 di corde"
print(guitar2.brand) ///"apple"

///Polymorphism
///che cosa è?
///il punto Core, del OOP è proprio ereditare da una altra classe, ma comportarsi diversamente
///basta con gli strrumenti musicali, pensiamo ad una squadra... ha dei giocatori ed una struttra "Team", non tutti i giocatori fanno la stessa cosa, ma hanno proprietà diverse, non voglio fare due classi "ripetitive" per ogni elemento e soprattuto dentro alla squadra non posso specificare che tipo di giocatore mi serve, altrimenti dovrei modificare ogni volta i parametri interni.... Ma che mi servono dei "giocatori"!

///classe di base
class Player {
    ///param di base
  let name: String
    
    ///carichiamo...
  init(name: String) {
    self.name = name
  }
    ///metodo di base
  func play() { }
}

///eredita
class Ricevitore: Player {
    override func play() {
        print("\(name) is bowling")
    }
}
///utilizzando un metodo più concatenato con gli esempi visti prima... Encapsulation
class Battitore: Player {
    ///modifica un metodo di base
  override func play() {
    bat()
  }
    ///metodo interno
  private func bat() {
    print("\(name) is batting")
  }
}

///classe team per riassumere
class Team {
  let name: String
  let team: [Player]
  init(name: String, team: [Player]) {
    self.name = name
    self.team = team
  }
  func play() {
    team.forEach { $0.play() }
  }
}

let fabio = Battitore(name: "Fabio")
let ivano = Ricevitore(name: "Ivano")
let primoTeam = Team(name: "Red", team: [fabio, ivano])
primoTeam.play()

///tutto questo aiuta a creare classi più astratte, basi, su cui possiamo andare a lavorare e non creare una classe diversa solo perchè ho un parametro in più!
